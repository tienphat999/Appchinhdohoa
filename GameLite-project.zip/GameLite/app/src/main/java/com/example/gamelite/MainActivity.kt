package com.example.gamelite

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var revert: Runnable? = null
    private var physW = 0
    private var physH = 0
    private var physDpi = 0

    private lateinit var status: TextView
    private lateinit var label: TextView
    private lateinit var seek: SeekBar
    private lateinit var animSw: Switch

    private fun percent() = 50 + seek.progress * 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p * 2, p, p)
        }
        fun tv(s: String, size: Float = 15f) = TextView(this).apply {
            text = s; textSize = size; setPadding(0, p / 2, 0, p / 2)
        }

        root.addView(tv("GameLite", 24f))
        status = tv("")
        root.addView(status)

        label = tv("")
        root.addView(label)
        seek = SeekBar(this).apply { max = 10; progress = 5 }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) = updateLabel()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)

        animSw = Switch(this).apply { text = "Tắt hiệu ứng chuyển cảnh (animation)"; isChecked = true }
        root.addView(animSw)

        root.addView(Button(this).apply {
            text = "Áp dụng"
            setOnClickListener { applyAll() }
        })
        root.addView(Button(this).apply {
            text = "Khôi phục mặc định"
            setOnClickListener { resetAll() }
        })

        root.addView(tv(
            "ℹ️ Độ nhạy vuốt X/Y: Android không cho app thường chỉnh cảm ứng của game khác " +
                "(cần root hoặc tính năng riêng của hãng máy). Hãy chỉnh trong phần Sensitivity/Camera " +
                "của game, hoặc dùng Game Mode / Game Turbo của máy.", 13f
        ))

        setContentView(ScrollView(this).apply { addView(root) })
        updateLabel()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- helpers ----------

    private fun hasPerm() =
        checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    private fun sh(cmd: String): Pair<Int, String> = try {
        val pr = Runtime.getRuntime().exec(arrayOf("sh", "-c", "$cmd 2>&1"))
        val out = pr.inputStream.bufferedReader().readText().trim()
        pr.waitFor() to out
    } catch (e: Exception) {
        -1 to (e.message ?: "lỗi không rõ")
    }

    private fun ok(r: Pair<Int, String>) =
        r.first == 0 && !Regex("error|exception|denied", RegexOption.IGNORE_CASE).containsMatchIn(r.second)

    private fun updateLabel() {
        val pc = percent()
        val extra = if (physW > 0) " (${physW * pc / 100 / 2 * 2}x${physH * pc / 100 / 2 * 2})" else ""
        label.text = "Độ phân giải: $pc%$extra"
    }

    private fun refresh() {
        status.text = if (hasPerm()) "✅ Đã có quyền WRITE_SECURE_SETTINGS"
        else "❌ Chưa có quyền. Chạy trên máy tính:\nadb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        thread {
            val size = sh("wm size").second
            val dpi = sh("wm density").second
            Regex("Physical size: (\\d+)x(\\d+)").find(size)?.let {
                physW = it.groupValues[1].toInt(); physH = it.groupValues[2].toInt()
            }
            Regex("Physical density: (\\d+)").find(dpi)?.let { physDpi = it.groupValues[1].toInt() }
            if (physW == 0 || physH == 0) { // dự phòng nếu không đọc được lệnh wm
                val m = resources.displayMetrics
                physW = minOf(m.widthPixels, m.heightPixels)
                physH = maxOf(m.widthPixels, m.heightPixels)
            }
            if (physDpi == 0) physDpi = resources.displayMetrics.densityDpi
            ui.post { updateLabel() }
        }
    }

    private fun setAnim(scale: Float): Boolean = try {
        listOf(
            Settings.Global.WINDOW_ANIMATION_SCALE,
            Settings.Global.TRANSITION_ANIMATION_SCALE,
            Settings.Global.ANIMATOR_DURATION_SCALE
        ).forEach { Settings.Global.putFloat(contentResolver, it, scale) }
        true
    } catch (e: SecurityException) {
        false
    }

    // ---------- actions ----------

    private fun applyAll() {
        if (physW == 0) return
        val pc = percent()
        val w = physW * pc / 100 / 2 * 2
        val h = physH * pc / 100 / 2 * 2
        val dpi = physDpi * pc / 100
        val anim = animSw.isChecked
        // Giảm cả density để giao diện hệ thống không bị phóng to
        val cmdSize = if (pc == 100) "wm size reset" else "wm size ${w}x$h"
        val cmdDpi = if (pc == 100) "wm density reset" else "wm density $dpi"

        thread {
            val r1 = sh(cmdSize)
            val r2 = sh(cmdDpi)
            val animOk = if (anim) setAnim(0f) else true
            ui.post {
                if (ok(r1) && ok(r2) && animOk) {
                    askConfirm()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Không chạy được")
                        .setMessage(
                            "Hãy cấp quyền (xem dòng trạng thái) hoặc chạy thủ công trên máy tính:\n\n" +
                                "adb shell $cmdSize\nadb shell $cmdDpi\n\nChi tiết: ${r1.second} ${r2.second}"
                        )
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }
    }

    private fun askConfirm() {
        val d = AlertDialog.Builder(this)
            .setTitle("Giữ cài đặt này?")
            .setMessage("Tự khôi phục sau 15 giây nếu bạn không bấm Giữ.")
            .setCancelable(false)
            .setPositiveButton("Giữ") { _, _ -> revert?.let { ui.removeCallbacks(it) } }
            .setNegativeButton("Khôi phục") { _, _ -> resetAll() }
            .create()
        revert = Runnable {
            try { d.dismiss() } catch (_: Exception) {}
            resetAll()
        }
        d.show()
        ui.postDelayed(revert!!, 15_000)
    }

    private fun resetAll() {
        revert?.let { ui.removeCallbacks(it) }
        thread {
            sh("wm size reset")
            sh("wm density reset")
            setAnim(1f)
            ui.post { Toast.makeText(this, "Đã khôi phục", Toast.LENGTH_SHORT).show() }
        }
    }
}
